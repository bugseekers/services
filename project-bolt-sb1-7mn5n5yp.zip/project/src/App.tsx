import React from 'react';
import { Shield, Search, Database, Globe, Lock, AlertTriangle, BarChart3, CheckCircle, ArrowRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Navigation */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">Bug Seekers</span>
            </div>
            <div className="flex items-center">
              <a href="https://rzp.io/rzp/2xHNhjRz" className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                Sign Up
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="relative z-10 py-8 bg-white sm:py-16 md:py-20 lg:py-28 xl:py-32">
            <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="text-center">
                <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                  <span className="block">Stay Secure with Our</span>
                  <span className="block text-blue-600">₹999/Month Security Checkup!</span>
                </h1>
                <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl">
                  Protect your business from cyber threats with a monthly security audit and actionable report.
                </p>
                <div className="mt-5 sm:mt-8 sm:flex sm:justify-center">
                  <div className="rounded-md shadow">
                    <a href="https://rzp.io/rzp/2xHNhjRz" className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10">
                      Get Your Security Checkup Now
                    </a>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>

      {/* Why Choose Us Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Benefits</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              Why Choose Us?
            </p>
          </div>

          <div className="mt-12">
            <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-12">
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <CheckCircle className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Affordable Monthly Security Audits</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Get comprehensive security checks at a fraction of the cost of traditional security services.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <CheckCircle className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Expert Cybersecurity Analysis</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Our team of security professionals uses industry-leading tools and methodologies.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <CheckCircle className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Actionable Reports & Fixes</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Receive clear, actionable recommendations to address vulnerabilities quickly.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <CheckCircle className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Continuous Protection & Monitoring</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Stay protected with ongoing monitoring and regular security updates.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* What's Included Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Services</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              What's Included?
            </p>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Our comprehensive security checkup covers all aspects of your online presence.
            </p>
          </div>

          <div className="mt-12">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <Search className="h-6 w-6" />
                  </div>
                  <h3 className="ml-4 text-lg font-medium text-gray-900">Website & Server Security Scan</h3>
                </div>
                <p className="text-gray-500">Comprehensive scanning for vulnerabilities in your website and server infrastructure.</p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <Database className="h-6 w-6" />
                  </div>
                  <h3 className="ml-4 text-lg font-medium text-gray-900">Data Leak & Dark Web Monitoring</h3>
                </div>
                <p className="text-gray-500">Continuous monitoring for your data appearing in breaches or on the dark web.</p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <Globe className="h-6 w-6" />
                  </div>
                  <h3 className="ml-4 text-lg font-medium text-gray-900">Subdomain & Asset Discovery</h3>
                </div>
                <p className="text-gray-500">Identify all your digital assets and subdomains to ensure complete protection.</p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <Lock className="h-6 w-6" />
                  </div>
                  <h3 className="ml-4 text-lg font-medium text-gray-900">SSL & Security Headers Check</h3>
                </div>
                <p className="text-gray-500">Verify your SSL certificates and security headers are properly configured.</p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <AlertTriangle className="h-6 w-6" />
                  </div>
                  <h3 className="ml-4 text-lg font-medium text-gray-900">Malware & Phishing Analysis</h3>
                </div>
                <p className="text-gray-500">Detect and remove malware, and protect against phishing attempts targeting your business.</p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <BarChart3 className="h-6 w-6" />
                  </div>
                  <h3 className="ml-4 text-lg font-medium text-gray-900">Monthly Security Report</h3>
                </div>
                <p className="text-gray-500">Detailed monthly reports with actionable insights to improve your security posture.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Pricing</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              Affordable Security for Your Business
            </p>
          </div>

          <div className="mt-12 flex justify-center">
            <div className="rounded-lg shadow-lg overflow-hidden max-w-lg w-full transform transition-transform duration-300 hover:scale-105">
              <div className="px-6 py-8 bg-white sm:p-10 sm:pb-6">
                <div>
                  <h3 className="inline-flex px-4 py-1 rounded-full text-sm font-semibold tracking-wide uppercase bg-blue-100 text-blue-600">
                    Full Security Checkup + Report
                  </h3>
                </div>
                <div className="mt-4 flex items-baseline text-6xl font-extrabold">
                  ₹999
                  <span className="ml-1 text-2xl font-medium text-gray-500">/month</span>
                </div>
                <p className="mt-5 text-lg text-gray-500">
                  Complete protection for your online business
                </p>
              </div>
              <div className="px-6 pt-6 pb-8 bg-gray-50 sm:p-10 sm:pt-6">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="flex-shrink-0">
                      <CheckCircle className="h-6 w-6 text-green-500" />
                    </div>
                    <p className="ml-3 text-base text-gray-700">All security checks included</p>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0">
                      <CheckCircle className="h-6 w-6 text-green-500" />
                    </div>
                    <p className="ml-3 text-base text-gray-700">Detailed monthly report</p>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0">
                      <CheckCircle className="h-6 w-6 text-green-500" />
                    </div>
                    <p className="ml-3 text-base text-gray-700">Actionable security recommendations</p>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0">
                      <CheckCircle className="h-6 w-6 text-green-500" />
                    </div>
                    <p className="ml-3 text-base text-gray-700">Email support</p>
                  </li>
                </ul>
                <div className="mt-8">
                  <div className="rounded-md shadow">
                    <a href="https://rzp.io/rzp/2xHNhjRz" className="flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors duration-300">
                      Secure My Website Now
                    </a>
                  </div>
                </div>
                <div className="mt-4 text-sm text-center">
                  <span className="font-medium text-blue-600">Limited Offer:</span>
                  <span className="font-medium text-gray-900"> Get your first scan in 24 hours!</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="bg-gray-50">
        <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:py-20 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div>
              <h2 className="text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                <span className="block">Ready to secure your business?</span>
                <span className="block text-blue-600">Start your security checkup today.</span>
              </h2>
              <p className="mt-4 text-lg text-gray-500">
                Our team of security experts is ready to help protect your business from cyber threats.
                Sign up now and get your first security scan within 24 hours.
              </p>
            </div>
            <div className="mt-8 lg:mt-0 flex justify-center lg:justify-end">
              <div className="inline-flex rounded-md shadow">
                <a href="https://rzp.io/rzp/2xHNhjRz" className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors duration-300">
                  Get started
                  <ArrowRight className="ml-2 -mr-1 h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white">
        <div className="max-w-7xl mx-auto py-12 px-4 overflow-hidden sm:px-6 lg:px-8">
          <div className="flex flex-col items-center justify-center">
            <div className="flex flex-col items-center">
              <div className="flex items-center mb-4">
                <Shield className="h-6 w-6 text-blue-600 mr-2" />
                <span className="font-medium text-lg text-gray-900">Bug Seekers</span>
              </div>
              <address className="text-center not-italic">
                <p className="text-gray-500">No 58 Balandeeswarar Koil Street</p>
                <p className="text-gray-500">Mangadu, Chennai - 600122</p>
              </address>
              <div className="mt-4 space-y-2">
                <a href="mailto:info@bugseekers.in" className="block text-center text-blue-600 hover:text-blue-500 transition-colors duration-300">info@bugseekers.in</a>
                <a href="https://bugseekers.in" className="block text-center text-blue-600 hover:text-blue-500 transition-colors duration-300">BugSeekers.in</a>
              </div>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-200 pt-8">
            <p className="text-center text-base text-gray-400">
              &copy; 2025 Bug Seekers. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;